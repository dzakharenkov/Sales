# Core: security, dependencies
